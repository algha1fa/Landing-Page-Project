/* Manipulating the DOM exercise.
it's builds dynamically navigation, with scroll and anchor effected from navigation,
the height section depends on scrolling effects inside this landing page.

*/

// Below define all global variables

let navbarList = document.querySelector("#navbar__list");
const sections = document.querySelectorAll("section");

 // / Here end of global variables

// Now start helper functions below

/* Function to check if an elements is in viewport or it's not 
*/
var isInViewport = function (elem) {
	var distance = elem.getBoundingClientRect();
	return (
		distance.top >= 0 &&
		distance.left >= 0 &&
		distance.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
		distance.right <= (window.innerWidth || document.documentElement.clientWidth)
	);
};

// Function to remove active classes
function deactivateSections() {
    sections.forEach((element)=>{
        element.classList.remove("active");
    });
}

function deactivateNavLinks() {
    let navbarAnchors = document.querySelectorAll(".nav__hyperlink");
    navbarAnchors.forEach((element)=>{
        element.classList.remove("active-nav");
    });
}

// / End of helper function

// Build the navigation
window.addEventListener('load', buildNavbar())

 /* Add class 'active' to section when almost near top of viwport
 */
function activateCurrentSection(currentSection) {
    currentSection.classList.add("active");

    deactivateNavLinks();
    activateNavLinks(currentSection.getAttribute('id'));
}

function activateNavLinks(currentSectionId) {
    let navbarAnchors = document.querySelectorAll(".nav__hyperlink");
   
    // console.log used for navbarAnchors
    
        navbarAnchors.forEach((element)=>{
            if(element.getAttribute('href') == `#${currentSectionId}`) {
                element.classList.add("active-nav");
            }
        });
}

 // Scroll to Anchor ID by using scrollto event
function scrollToSectionOnClick() {
    let navbarAnchors = document.querySelectorAll(".nav__hyperlink");
    navbarAnchors.forEach((element) => {
        element.addEventListener("click", function(event) {
            event.preventDefault();
            document.querySelector(element.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
}

 // / End of main functions

/* Build Menu of landing page */

function buildNavbar() {
	sections.forEach((element)=>{
	    let listItem = document.createElement("li");
	    listItem.classList.add("navbar__list__item");
    	let sectionName = element.getAttribute("data-nav");
    	let currentSectionId = element.getAttribute("id");
        listItem.innerHTML = `<a href="#${currentSectionId}" class="nav__hyperlink">${sectionName}</a>`;
        navbarList.appendChild(listItem);
    });
}

 // Scroll to section on link click
scrollToSectionOnClick();


 // Set section as an active parts
window.addEventListener('scroll', function (event) {
    sections.forEach((element)=>{
        // console.log(element)
        if (isInViewport(element)) {
            deactivateSections();
            activateCurrentSection(element);
            //console.log('In viewport!');
        } else if(window.scrollY==0) {
            deactivateSections();
            deactivateNavLinks();
            //console.log('No Change');
        }
    }, false);
});