/*
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
*/

/**
 * Define Global Variables
 * 
*/
let navbarList = document.querySelector("#navbar__list");
const sections = document.querySelectorAll("section");
let toplink = document.querySelector("#toplink")


/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
//var isElementInViewport =  (elem)=> {
/* 

Funcation Name : isElementInViewport
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions is going to check whether  the passed section is in viewport(visible currently) 
and return boolean value depending on the  

*/
function isElementInViewport(elem)
{
    //alert("In the viewport");
    var distance = elem.getBoundingClientRect();
    let isin =  (distance.top >= 0 && distance.left >= 0 && distance.right <= window.innerWidth && distance.bottom <= window.innerHeight) ;
 	return isin;
};

/* 

Funcation Name : hideheader
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions is going to hide the header(menu bar) from dispaying  

*/


function hideheader()
{
 //   alert("hiding")
    setTimeout(function(){ 
    let header = document.querySelector("header");
    header.classList.add("hide");
 }, 500);
}

/* 

Funcation Name : showheader
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions is going to display  header(menu bar) if its hidden

*/


function showheader()
{
setTimeout(function(){ 
    let header = document.querySelector("header");
    header.classList.remove("hide");
 }, 1);
}

/* 

Funcation Name : ResetAllSections
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions is going to reset the default style of all  section by removing the active class
from all of the sections

*/



function ResetAllSections() {
    sections.forEach((element)=>{
        element.classList.remove("active");
    });
}

/* 

Funcation Name : ResetAllNavLinks
Date of creation :3-Nov-2020
Author :Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions is going to reset the default style of all  links in menu bar by removing the active class
from all of the links

*/




function ResetAllNavLinks() {
    let navbarAnchors = document.querySelectorAll(".nav__hyperlink");
    navbarAnchors.forEach((element)=>{
        element.classList.remove("active-nav");
    });
}
/* 

Funcation Name : ActivateSelctedSection
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions is going to set the current section the active

*/



function ActivateSelctedSection(currentSection) {
    currentSection.classList.add("active");
   ResetAllNavLinks();
    ActivateSelctedLink(currentSection.getAttribute('id'));
}


/* 

Funcation Name : ActivateSelctedLink
Date of creation :3-Nov-2020
Author :
Date of Last Update :7-Nov-2020
Descrption : This functions is going to set the  link of corresponding selected(active) section the active

*/


function ActivateSelctedLink(currentSectionId) {
    let navbarAnchors = document.querySelectorAll(".nav__hyperlink");

    navbarAnchors.forEach((element)=>{
            if(element.getAttribute('href') == `#${currentSectionId}`) {
                element.classList.add("active-nav");
            }
        });
}






/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav

window.addEventListener('load', CreateNavBar())

/* 

Funcation Name : CreateNavBar
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions event listner for load event.It builds a menu bar dynamically,Reset all sections
and links.It also adds a Goto Top link dynamically atthe bottom of page

*/

function CreateNavBar() {
//    alert("build")
	sections.forEach((element)=>{
	    let listItem = document.createElement("li");
	    listItem.classList.add("navbar__list__item");
    	let sectionName = element.getAttribute("data-nav");
    	let currentSectionId = element.getAttribute("id");
        listItem.innerHTML = `<a href="#${currentSectionId}" class="nav__hyperlink">${sectionName}</a>`;
        navbarList.appendChild(listItem);
    });
 
    ResetAllSections();
    ResetAllNavLinks();

    let gotopitem = document.createElement("a");
    gotopitem.innerHTML = `<a href="#section1" >Go to Top</a>`
    console.log(gotopitem);
    toplink.appendChild(gotopitem);
	 
}



var coll = document.getElementsByName("collapsibleSection");

for (var i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}

// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click
/* 

Funcation Name : GotoSectonOnScroll
Date of creation :3-Nov-2020
Author : Fahad Alghamdi
Date of Last Update :7-Nov-2020
Descrption : This functions scrolls to selected section.By default whenn we click on the link ,it would go to section sine
we have dynamically added href in functio createnavabar.y using preventDefault() of event and adding click even or link,we override this default 
behaviour and scroll to that functon section smoothly.

*/





function GotoSectonOnScroll() {
    let navbarAnchors = document.querySelectorAll(".nav__hyperlink");
    navbarAnchors.forEach((element) => {
        element.addEventListener("click", (event)=> {
            //To prevent default behaviour
            event.preventDefault();
            document.querySelector(element.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
}
GotoSectonOnScroll();


// Set sections as active




window.addEventListener('scroll',  (event) =>{
    sections.forEach((element)=>{
        // console.log(element)
        if (isElementInViewport(element)) {
            ResetAllSections();
            ActivateSelctedSection(element);
            //console.log('In viewport!');
        } else if(window.scrollY==0) {
            //alert("HEre");
            //alert(window.scrollY)
            ResetAllSections();
            ResetAllNavLinks();
            hideheader();
                //console.log('No Change');
        }
        else if(window.scrollY>0)
        {
            showheader();

        }
    }, false);
    
});



