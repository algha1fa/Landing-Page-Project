This project shows how the javascript can be used to dynamically change the HTML pages.it shows the capablity of adding new elements and changing the style of existing element.

W.r.t starer code given following changes are made or added
Files:
-------
index.html: 
  Reference to the app.js is been added. To make section collapsable ,we have applied collapsible and content classes to the html element.

style.css:
----------

There were multiple background property applied.
  background: rgb(255,255,255,0.187);
  background: linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%);*/
  
  Have removed linear-gradient line, so color is visible properly.otherwise color was getting overrideen.

Following new classes has been added

1>To add backgrounf colot for navbar
#navbar__list {
    background: #f6e505;
}

2>set margin properties for each item in navbar
.navbar__list__item {
    margin: 1rem;
}

3>To distinguish active section(in viewport) from other sections 
.active-nav {
    color: red;
}

4>To make the section name collapsible and display content
.collapsible {
    background-color: green;
    color: white;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
  }
  
  5>To mark selected section as active
  .active {
    background-color: yellow;
  }
  
  6>To  change background color while mouse-hover
  .collapsible:hover {
    background-color: #555;
  }
 7>Text contents of sections  property
  .content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
  background-color: #f1f1f1;
}

  
app.js
------
1>
function isElementInViewport(elem)
THis checks weather given element is within the viewoet area and return true otherwise false

2>showheader() and hideheader() functions shows and hides header respectivelly.

3>ResetAllSections() : sets default property for all sectons

4>ResetAllNavLinks : sets default property for all links

5>ActivateSelctedSection : set active property for last selected 

6>ActivateSelctedLink : set active property of last selected link

7>Load event:While pages loads CreateNavBar() works as event iistner, which will build the menu bar dynamically

8>GotoSectonOnScroll : This will be called when user scroll down page
